<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
  <title>Library Administration Home Page</title>
</head>
<body>
<IMG src="images/library.jpg" width="300" height="200" >
<hr>
<h3> Welcome to the Library Admin Site! </h3>
<a href="addbook.php">Add a new book</a>
<br>
<a href="addborrower.php">Add a new borrower</a>
<br>
<a href="adminbooksearch.html">Search, checkout and checkin</a>
<br>
</body>
</html>
