<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
  <title>Library Home Page</title>
</head>
<body>
<IMG src="images/library.jpg" width="300" height="200" >
<hr>
<h3> Welcome to the Library! </h3>
<A href="booksearch.html">Browse our books</A>
<br>
<A href="showreservedbooks.php">Show my reserved books</A>
<br>
<A href="colour-chooser.php">Select colour preference</A>
<br>
<A href="contactus.html">Contact Us</a>
</body>
</html>
