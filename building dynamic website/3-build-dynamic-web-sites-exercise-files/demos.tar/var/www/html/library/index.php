<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
  <title>Library Home Page</title>
</head>
<body>
<IMG src="images/library.jpg" width="300" height="200" >
<?php
  date_default_timezone_set('UTC');
  echo "time is " . date("h:i:s:") . "<br>";
?>
<hr>
<h3> Welcome to the Library! </h3>
<A href="booksearch.html">Browse our books</A>
</body>
</html>
